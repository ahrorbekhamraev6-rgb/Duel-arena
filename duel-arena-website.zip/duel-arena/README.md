# Duel Arena: website + game + multiplayer server

A real, self-hosted website. Nothing here depends on Claude.

```
duel-arena/
  server.js        Serves ./public and runs the multiplayer relay (WebSocket at /ws). No npm install needed.
  package.json     "npm start" runs server.js (Node 18+).
  public/
    index.html     The marketing website
    play.html      The game
    net.js         Multiplayer client (talks to server.js)
```

## Run it on your computer

```
cd duel-arena
node server.js
```

Open http://localhost:3000. Solo modes, team matches vs bots and the shooting range work immediately. Friends mode works too: open the page in two browser tabs, create a room in one, join with the code in the other.

## Put it on the internet

**Option A: everything on one Node host (easiest, friends mode works)**
Deploy this folder to any Node host (Render, Railway, Fly.io, a VPS). Start command: `node server.js`. The host sets `PORT` for you. Point your domain at it and use HTTPS. If you put nginx or Caddy in front, it must forward WebSocket upgrades for `/ws`.

**Option B: static hosting + a separate server**
Upload only `public/` to Netlify, GitHub Pages or Cloudflare Pages (solo modes work with no server). For friends mode, run `server.js` somewhere and add this line to `play.html` just above `<script src="net.js">`:

```html
<script>window.DUEL_WS='wss://your-server.example.com/ws';</script>
```

Optionally lock the server to your site: `ORIGINS=https://yoursite.com node server.js`

## Notes

- The game loads three.js r128 and Google Fonts from public CDNs. To make it fully self-contained, download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js into `public/vendor/three.min.js` and change the script tag in `play.html`.
- Multiplayer is casual: players report their own hits, so there is no anti-cheat. Rooms hold up to 16 players and the server keeps nothing on disk.
- This is a fan-made game inspired by Roblox Rivals. Keep the "not affiliated with Roblox" line in the footer, and don't use Roblox logos or names as your branding.
