/* Duel Arena multiplayer client: a tiny presence-room layer over WebSocket.
   Set window.DUEL_WS = 'wss://your-server/ws' before this file if the game
   is hosted separately from server.js. */
(function(){
  var WS_URL=window.DUEL_WS||((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws');
  function merge(t,d){ for(var k in d){ if(d[k]===null) delete t[k]; else t[k]=d[k]; } }
  function join(name){
    return new Promise(function(resolve,reject){
      var ws,room,me=null,peers={},done=false;
      var timer=setTimeout(function(){ if(!done){ done=true; try{ws.close();}catch(e){} reject(new Error('timeout')); } },8000);
      try{ ws=new WebSocket(WS_URL); }catch(e){ clearTimeout(timer); return reject(e); }
      room={
        presence:function(p){ if(!me||!p) return; merge(peers[me],p); if(ws.readyState===1) ws.send(JSON.stringify({t:'p',d:p})); },
        peers:function(){ var a=[]; for(var id in peers) a.push({peer:id,sameTab:id===me,presence:peers[id]}); return a; },
        leave:function(){ try{ws.close();}catch(e){} }
      };
      ws.onopen=function(){ ws.send(JSON.stringify({t:'join',room:name})); };
      ws.onmessage=function(ev){
        var m; try{ m=JSON.parse(ev.data); }catch(e){ return; }
        if(m.t==='welcome'){ me=m.id; peers=m.peers||{}; peers[me]={}; done=true; clearTimeout(timer); resolve(room); }
        else if(m.t==='j'){ if(!peers[m.id]) peers[m.id]={}; }
        else if(m.t==='p'){ if(!peers[m.id]) peers[m.id]={}; merge(peers[m.id],m.d); }
        else if(m.t==='l'){ delete peers[m.id]; }
        else if(m.t==='full'){ done=true; clearTimeout(timer); reject(new Error('room full')); }
      };
      ws.onclose=function(){ if(me){ var mine=peers[me]||{}; peers={}; peers[me]=mine; } };
      ws.onerror=function(){ if(!done){ done=true; clearTimeout(timer); reject(new Error('connect')); } };
    });
  }
  window.claude=window.claude||{};
  window.claude.use=function(cap){ return Promise.resolve(cap==='room'?{join:join}:null); };
})();
