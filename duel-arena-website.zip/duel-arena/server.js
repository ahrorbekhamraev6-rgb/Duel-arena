/* Duel Arena server: serves ./public and relays multiplayer presence over WebSocket (/ws).
   No dependencies. Run:  node server.js   (PORT env var optional) */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=+process.env.PORT||3000;
const PUB=path.resolve(__dirname,'public');
const ORIGINS=(process.env.ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean);
const MAX_MSG=8*1024, MAX_PRES=16*1024, MAX_PEERS=16, MAX_RATE=80;
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.json':'application/json','.txt':'text/plain; charset=utf-8','.woff2':'font/woff2'};

const server=http.createServer((req,res)=>{
  let p; try{ p=decodeURIComponent(req.url.split('?')[0]); }catch(e){ res.writeHead(400); return res.end(); }
  if(p==='/') p='/index.html';
  const f=path.resolve(PUB,'.'+path.normalize(p));
  if(f!==PUB&&!f.startsWith(PUB+path.sep)){ res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(f,(e,d)=>{
    if(e){ res.writeHead(404,{'content-type':'text/plain; charset=utf-8'}); return res.end('Not found'); }
    res.writeHead(200,{'content-type':MIME[path.extname(f).toLowerCase()]||'application/octet-stream','cache-control':'no-cache','x-content-type-options':'nosniff'});
    res.end(d);
  });
});

/* ---- minimal WebSocket (RFC 6455) ---- */
function frame(payload,op){
  const len=payload.length; let h;
  if(len<126) h=Buffer.from([128|op,len]);
  else if(len<65536){ h=Buffer.alloc(4); h[0]=128|op; h[1]=126; h.writeUInt16BE(len,2); }
  else{ h=Buffer.alloc(10); h[0]=128|op; h[1]=127; h.writeBigUInt64BE(BigInt(len),2); }
  return Buffer.concat([h,payload]);
}
function send(c,obj){
  if(c.socket.destroyed||c.socket.writableLength>1e6) return;
  c.socket.write(frame(Buffer.from(JSON.stringify(obj)),1));
}
function parse(c){
  for(;;){
    const b=c.buf; if(b.length<2) return;
    const fin=!!(b[0]&128), op=b[0]&15, masked=!!(b[1]&128); let len=b[1]&127, off=2;
    if(len===126){ if(b.length<4) return; len=b.readUInt16BE(2); off=4; }
    else if(len===127){ if(b.length<10) return; len=Number(b.readBigUInt64BE(2)); off=10; }
    if(len>MAX_MSG){ c.socket.destroy(); return; }
    const total=off+(masked?4:0)+len; if(b.length<total) return;
    let payload=b.subarray(off+(masked?4:0),total);
    if(masked){ const m=b.subarray(off,off+4); payload=Buffer.from(payload); for(let i=0;i<payload.length;i++) payload[i]^=m[i&3]; }
    c.buf=b.subarray(total);
    if(op===8){ c.socket.end(frame(Buffer.alloc(0),8)); return; }
    if(op===9){ c.socket.write(frame(payload,10)); continue; }
    if(op===10){ continue; }
    if(op===1||op===2){ c.fr=[payload]; c.fop=op; } else if(op===0&&c.fr){ c.fr.push(payload); }
    if(fin&&c.fr){ const m=Buffer.concat(c.fr); c.fr=null; if(c.fop===1&&m.length<=MAX_MSG) onMsg(c,m.toString('utf8')); }
  }
}

/* ---- rooms ---- */
const rooms=new Map();
const NAME=/^[a-z0-9][a-z0-9_.-]{0,47}$/;
function merge(t,d){ for(const k in d){ if(d[k]===null) delete t[k]; else t[k]=d[k]; } }
function broadcast(room,from,obj){ room.peers.forEach(c=>{ if(c!==from) send(c,obj); }); }
function leave(c){
  const r=c.room; if(!r) return; c.room=null; r.peers.delete(c.id);
  broadcast(r,c,{t:'l',id:c.id});
  if(!r.peers.size) rooms.delete(r.name);
}
function onMsg(c,txt){
  const now=Date.now(); if(now-c.rt>1000){ c.rt=now; c.rc=0; } if(++c.rc>MAX_RATE) return;
  let m; try{ m=JSON.parse(txt); }catch(e){ return; }
  if(!m||typeof m!=='object') return;
  if(m.t==='join'&&!c.room){
    if(typeof m.room!=='string'||!NAME.test(m.room)){ c.socket.destroy(); return; }
    let r=rooms.get(m.room); if(!r){ r={name:m.room,peers:new Map()}; rooms.set(m.room,r); }
    if(r.peers.size>=MAX_PEERS){ send(c,{t:'full'}); c.socket.end(); return; }
    c.id='p'+crypto.randomBytes(6).toString('hex');   /* never starts with "b" (the game reserves b0, b1... for bots) */
    c.room=r; c.pres={};
    const snap={}; r.peers.forEach(o=>{ snap[o.id]=o.pres; });
    r.peers.set(c.id,c);
    send(c,{t:'welcome',id:c.id,peers:snap});
    broadcast(r,c,{t:'j',id:c.id});
  } else if(m.t==='p'&&c.room){
    const d=m.d; if(!d||typeof d!=='object'||Array.isArray(d)) return;
    const next=Object.assign({},c.pres); merge(next,d);
    if(JSON.stringify(next).length>MAX_PRES) return;
    c.pres=next;
    broadcast(c.room,c,{t:'p',id:c.id,d});
  }
}
server.on('upgrade',(req,socket)=>{
  const key=req.headers['sec-websocket-key'];
  const okOrigin=!ORIGINS.length||ORIGINS.includes(req.headers.origin);
  if(req.url.split('?')[0]!=='/ws'||String(req.headers.upgrade).toLowerCase()!=='websocket'||!key||!okOrigin){ socket.destroy(); return; }
  const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
  socket.setNoDelay(true);
  const c={socket,id:null,room:null,pres:{},buf:Buffer.alloc(0),fr:null,fop:0,alive:true,rt:0,rc:0};
  socket.on('data',d=>{ c.alive=true; c.buf=Buffer.concat([c.buf,d]); parse(c); });
  socket.on('close',()=>leave(c));
  socket.on('error',()=>socket.destroy());
});
/* drop dead connections */
setInterval(()=>{
  rooms.forEach(r=>r.peers.forEach(c=>{
    if(!c.alive){ c.socket.destroy(); return; }
    c.alive=false; if(!c.socket.destroyed) c.socket.write(frame(Buffer.alloc(0),9));
  }));
},30000).unref();

server.listen(PORT,()=>console.log('Duel Arena running on http://localhost:'+PORT));
module.exports=server;
